create
    definer = root@`127.0.0.1` procedure GetCommentsByPostID(IN PostID bigint)
BEGIN
    SELECT pc.*, usr.name, usr.username
    FROM post_comment pc
             inner join user_login usr on pc.pc_author_id = usr.user_id
    WHERE pc.post_id = PostID
      and pc.reported = 0
    ORDER BY pc.CREATED_AT asc;
END;

