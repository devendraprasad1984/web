create
    definer = root@`127.0.0.1` procedure GetAllPosts(IN UserID bigint, IN groupId bigint, IN groupByCompany tinyint(1),
                                                     IN searchVal varchar(300), IN recLimit tinyint)
BEGIN
    IF (groupId = -1) THEN
        SELECT p.*, cat.post_topic, IF(p.post_anonymous = 0,  concat(usr.name, ' from ', com.company_name), concat('Anonymous user from ', com.company_name)) as name, usr.username,usr.email, usr.user_id
        FROM POSTS p
                 inner join user_login usr on p.author_id = usr.user_id and usr.reported = 0
                 inner join company_detail com on com.company_id = usr.company_id
                 inner join post_category cat on cat.post_cat_id = p.post_cat_id
        where (
                lower(p.content) like concat('%', lower(searchVal), '%')
                or lower(p.post_title) like concat('%', lower(searchVal), '%')
                or concat('@',lower(usr.name)) like concat('%', lower(searchVal), '%')
                or lower(usr.email) like concat('%', lower(searchVal), '%')
                or concat('@',usr.name, ' from ', com.company_name) like concat('%', lower(searchVal), '%')
                or concat('#', lower(cat.post_topic)) like concat('%', lower(searchVal), '%')
            )
          and p.reported = 0
        ORDER BY p.CREATED_AT desc LIMIT recLimit;
    ELSE
        IF (UserID != 0) THEN
            SELECT p.*, cat.post_topic, IF(p.post_anonymous = 0,  concat(usr.name, ' from ', com.company_name), concat('Anonymous user from ', com.company_name)) as name, usr.username,usr.email, usr.user_id
            FROM POSTS p
                     inner join user_login usr on p.author_id = usr.user_id and usr.reported = 0
                     inner join company_detail com on com.company_id = usr.company_id
                     inner join post_category cat on cat.post_cat_id = p.post_cat_id
            WHERE (p.AUTHOR_ID = UserID OR usr.company_id = groupId)
              and (
                    lower(p.content) like concat('%', lower(searchVal), '%')
                    or lower(p.post_title) like concat('%', lower(searchVal), '%')
                    or concat('@',lower(usr.name)) like concat('%', lower(searchVal), '%')
                    or lower(usr.email) like concat('%', lower(searchVal), '%')
                    or concat('@',usr.name, ' from ', com.company_name) like concat('%', lower(searchVal), '%')
                    or concat('#', lower(cat.post_topic)) like concat('%', lower(searchVal), '%')
                )
              and p.reported = 0
            ORDER BY p.CREATED_AT desc LIMIT recLimit;
        ELSE
            SELECT p.*, cat.post_topic, IF(p.post_anonymous = 0,  concat(usr.name, ' from ', com.company_name), concat('Anonymous user from ', com.company_name)) as name, usr.username,usr.email, usr.user_id
            FROM POSTS p
                     inner join user_login usr on p.author_id = usr.user_id and usr.reported = 0
                     inner join company_detail com on com.company_id = usr.company_id
                     inner join post_category cat on cat.post_cat_id = p.post_cat_id
            WHERE (usr.company_id = groupId)
              and (
                    lower(p.content) like concat('%', lower(searchVal), '%')
                    or lower(p.post_title) like concat('%', lower(searchVal), '%')
                    or concat('@',lower(usr.name)) like concat('%', lower(searchVal), '%')
                    or lower(usr.email) like concat('%', lower(searchVal), '%')
                    or concat('@',usr.name, ' from ', com.company_name) like concat('%', lower(searchVal), '%')
                    or concat('#', lower(cat.post_topic)) like concat('%', lower(searchVal), '%')
                )
              and p.reported = 0
            ORDER BY p.CREATED_AT desc LIMIT recLimit;
        END IF;
    END IF;
END;

