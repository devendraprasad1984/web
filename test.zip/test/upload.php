<?php
$data['post']=$_POST;
$data['files']=$_FILES;
echo json_encode($data);
?>
