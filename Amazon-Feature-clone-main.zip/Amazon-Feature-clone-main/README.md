# Amazon-Feature-clone

*Live Link https://e-com-feature.vercel.app/

Used: React,Tailwind CSS 3.0,Commerce JS for Backend.

## Features

The features include:

* 📝 Full E-Commerce application.
* 📡 Realtime database From CommerceJS.
* 📦 Full responsive
* 📡 Hosted on Vercel.

![Screenshot (30)](https://user-images.githubusercontent.com/91312245/148933073-7ca929fa-dbd7-44fa-a5a3-887ce10b41b2.png)
![Screenshot (31)](https://user-images.githubusercontent.com/91312245/148933089-929a9162-33db-4915-9579-e1aba0719738.png)
![mobile1](https://user-images.githubusercontent.com/91312245/148933095-1830bc82-c982-45c8-90ae-fc2832b4b486.jpg)
![mobile2](https://user-images.githubusercontent.com/91312245/148933102-fcccd5dc-e698-4d23-96fa-618e6fec1f5f.jpg)
